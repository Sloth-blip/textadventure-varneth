package engine.player;

public class KnownSpell {

    private String spellId;
    private int level;
    private int manaCost;
    private String description;



}
