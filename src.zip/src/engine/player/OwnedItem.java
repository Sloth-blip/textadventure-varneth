package engine.player;

public class OwnedItem {
}
