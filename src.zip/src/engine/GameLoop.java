package engine;


import engine.player.PlayerState;
import systems.actors.enemy.EnemyState;
import systems.actors.interactables.PointofInterestState;
import systems.combat.CombatScene;
import systems.rooms.ExplorationPhase;
import systems.rooms.RoomState;
import ui.ConsoleMenu;

import java.util.ArrayList;
import java.util.List;

public class GameLoop {


    public void gameLoopStart(PlayerState player) {

        ui.ConsoleMenu userInterface = new ui.ConsoleMenu();

        var book = new PointofInterestState(
                "Buch",
                List.of("Very book", "such knowledge", "wow"),
                true);
        var cabinet = new PointofInterestState(
                "Schrank",
                List.of("Dings"),
                false
        );

        List<PointofInterestState> pOIS = new ArrayList<>();
        pOIS.add(book);pOIS.add(cabinet);

        var begin = new RoomState(
                1,
                "Beginn",
                "Der erste Raum",
                List.of("Spielintro.", "Blablabla", "Bla.", "Bla?", "Bla!"),
                pOIS
        );

        List<EnemyState> beginEnemies = new ArrayList<>();
        beginEnemies.add(new EnemyState("bat"));
        beginEnemies.add(new EnemyState("slime"));
        begin.setEnemies(beginEnemies);

        var second = new RoomState(
                2,
                "Weiter",
                "Der zweite Raum",
                List.of("Hier geht es weiter.", "Du kannst nur zurück."),
                List.of()
        );

        begin.setConnectedRooms(List.of(second));
        second.setConnectedRooms(List.of(begin));
        second.setEnemies(List.of());


        var cS = new CombatScene();
        var eP = new ExplorationPhase();

        var currentRoom = begin;




        boolean running = true;

        while (running) {


            ConsoleMenu.ExplorationAction nextStep = eP.explorationPhase(currentRoom);

            switch (nextStep){
                case COMBAT ->{
                    CombatScene.CombatResult result = cS.combatLoop(player, currentRoom.getEnemies());
                    switch (result){
                        case WON -> {
                            System.out.println("Kampf gewonnen!");
                            currentRoom.setEnemies(List.of());
                        }
                        case LOST -> {
                            System.out.println("Kampf verloren, Game over!");
                            running = false;
                        }
                        case FLED -> System.out.println("Kampf entflohen!");
                    }
                }
                case INTERACTABLES -> {
                    eP.playInteractableDialog(currentRoom);
                }
                case ROOMDESCRIPTION -> eP.replayRoomDialog(currentRoom.getRoomDialogChunks());
                case ROOMNAVIGATION -> currentRoom = eP.chooseNextRoom(currentRoom);
                case MAINMENU -> {
                    ConsoleMenu.MainMenuAction mainMenuChoice = userInterface.consoleMenuMainMenu();
                    switch (mainMenuChoice){
                        case CONTINUE -> {}
                        case SAVE -> System.out.println("ToDo");
                        case LOAD -> System.out.println("ToDo");
                        case SETTINGS -> System.out.println("ToDo");
                        case END -> {
                            System.out.println("bye");
                            running = false;
                        }
                    }
                }
            }
        }
    }
}

