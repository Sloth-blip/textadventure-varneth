import engine.GameStart;

public class Main {

    public static void main(String[] args) {

        GameStart gameStart = new GameStart();
        gameStart.gameStartStart();

    }
}
