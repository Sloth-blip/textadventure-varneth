package systems.combat;

import engine.player.PlayerState;
import systems.actors.enemy.EnemyState;
import ui.ConsoleMenu;

import java.util.List;

public class CombatScene {

    public enum CombatResult {
        WON,
        LOST,
        FLED;
    }

    public CombatResult combatLoop(PlayerState player, List<EnemyState> enemies){

        ui.ConsoleMenu CMenu = new ConsoleMenu();
        CMenu.consoleMenuCombatSceneBegin(player, enemies);

        while (true){

            /** Player Combat **/

            ConsoleMenu.CombatAction cAction = CMenu.consoleMenuCombatMenu();
            switch (cAction){
                case BASICATTACK -> {
                    EnemyState target = CMenu.consoleMenuTargetChooser(enemies);
                    int dmg = player.defaultAttack();
                    System.out.println(target + " hat " + dmg + " Schaden erhalten!");
                    target.recieveDamage(dmg);
                    if(target.isDead()){
                        System.out.println(target + " besiegt!");
                    }
                    if (enemies.stream().allMatch(EnemyState::isDead)){
                        return CombatResult.WON;
                    }
                }
                case SPELL -> System.out.println("ToDo");
                case ITEM -> System.out.println("ToDo");
                case FLEE -> {
                    return CombatResult.FLED;
                }
            }


            /** Enemy Combat **/


            CMenu.consoleMenuCombatSceneState(player, enemies);
            for (EnemyState enemy : enemies) {
                if(!enemy.isDead()) {
                    int dmg = enemy.defaultAttack();
                    System.out.println(player + " hat " + dmg + " Schaden erhalten!");
                    player.recieveDamage(dmg);

                    if (player.isDead()) {
                        return CombatResult.LOST;
                    }
                }
            }
        }
    }
}