package systems.actors.npc;

public class NPCState {
}
