package systems.actors.enemy;

import engine.player.KnownSpell;

import java.util.List;

public class EnemyState {

    private String name;
    private int level;
    private int healthPointsMax;
    private int healthPointsCurrent;
    private int intelligence;
    private int strength;
    private List<KnownSpell> knownSpells;

    public String toString() {
        return name;
    }

    public EnemyState(String name) {
        this.name = name;
        this.level = 1;
        this.healthPointsMax = 10;
        this.healthPointsCurrent = 10;
        this.intelligence = 1;
        this.strength = 1;
    }

    /** Clampers **/
    private void clampHealthPoints(){
        if (this.healthPointsCurrent < 0) this.healthPointsCurrent = 0;
        if (this.healthPointsCurrent > this.healthPointsMax) this.healthPointsCurrent = this.healthPointsMax;
    }

    /** Getter **/

    public int getLevel() {
        return this.level;
    }

    public String getName() {
        return this.name;
    }

    public int getHealthPointsMax() {
        return this.healthPointsMax;
    }

    public int getHealthPointsCurrent() {
        return this.healthPointsCurrent;
    }

    /** Combat **/

    public int defaultAttack(){
        return this.strength + 1;
    }

    public void recieveDamage(int damage){
        this.healthPointsCurrent -= damage;
        clampHealthPoints();
    }

    public void heal(int heal) {
        this.healthPointsCurrent += heal;
        clampHealthPoints();
    }

    public boolean isDead() {
        return this.healthPointsCurrent == 0;
    }
}
