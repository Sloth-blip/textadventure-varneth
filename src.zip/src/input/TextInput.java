package input;

import java.util.Scanner;

public class TextInput {

    public Scanner scanner = new Scanner(System.in);

}
